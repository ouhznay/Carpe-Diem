import sqlite3

def addfooddata(type_list, allergen_list, expdate, desc):
    
    conn = sqlite3.connect('lifehack.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    type_dict = {'halal':0, 'vegetarian':0, 'vegan':0}
    allergen_dict = {'peanuts':0, 'seafood':0, 'dairy':0, 'wheat':0, 'treenuts':0, 'soybean':0}
    
    food_ctr = 0
    c.execute("""
    SELECT COUNT(*)
    FROM "Food";
    """)
    food_ctr = c.fetchone()[0] + 1

    for key in type_dict:
        if key in type_list:
            type_dict[key] = 1
            
    for key in allergen_dict:
        if key in allergen_list:
            allergen_dict[key] = 1

    c.execute("""
    INSERT INTO Food
    VALUES(?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?);
    """, (food_ctr, expdate, desc, 0, type_dict['halal'], type_dict['vegetarian'], type_dict['vegan'], allergen_dict['peanuts'], allergen_dict['seafood'], allergen_dict['dairy'], allergen_dict['wheat'], allergen_dict['treenuts'], allergen_dict['soybean']))
 
    conn.commit()
    conn.close()
    
def search(check_list):
    
    conn = sqlite3.connect('lifehack.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()

    type_dict = {'halal':0, 'vegetarian':0, 'vegan':0}
    allergen_dict = {'peanuts':0, 'seafood':0, 'dairy':0, 'wheat':0, 'treenuts':0, 'soybean':0}

    for key in type_dict:
        if key in check_list:
            type_dict[key] = 1
            
    for key in allergen_dict:
        if key in check_list:
            allergen_dict[key] = 1

    c.execute("""
    SELECT * FROM "Food"
    WHERE taken == 0 AND
    halal >= ? AND
    vegetarian >= ? AND
    vegan >= ? AND
    peanuts >= ? AND
    seafood >= ? AND
    dairy >= ? AND
    wheat >= ? AND
    treenuts >= ? AND
    soybean >= ?;
    """, (type_dict['halal'], type_dict['vegetarian'], type_dict['vegan'], allergen_dict['peanuts'], allergen_dict['seafood'], allergen_dict['dairy'], allergen_dict['wheat'], allergen_dict['treenuts'], allergen_dict['soybean']))

    data_list = []
    for i in c.fetchall():
        data = {}
        data['num'] = int(i['id'])
        data['expiry_date'] = str(i['expdate'])
        data['description'] = str(i['description'])
        data_list.append(data)
    conn.close()
    return data_list
    
def update(id):

    conn = sqlite3.connect('lifehack.db')
    conn.row_factory = sqlite3.Row
    c = conn.cursor()
    
    c.execute("""
    UPDATE Food SET
    "taken" = 1
    WHERE id = ?;
    """, (id,))

    conn.commit()
    conn.close()
    
    
    
        
