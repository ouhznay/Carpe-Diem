from flask import Flask, render_template, request
import sqlite3
from functions import addfooddata, search, update


type_list = []
allergen_list = []
check_list = []
data = []
expdate = desc = None

app = Flask(__name__)

@app.route('/', methods = ["GET"])
def root():
    return render_template('index.html')

# donating
@app.route('/donate', methods = ["GET"])
def donate():
    return render_template('donors_login_page.html')

@app.route('/donor_login', methods = ["GET"])
def donating():
    return render_template('food_donated.html')

@app.route('/updatefooddata', methods = ["GET"])
def fooddata():
    for i in request.args:
        type_list.append(i)
    return render_template('allergen.html')

@app.route('/updateallergendata', methods = ["GET"])
def allergendata():
    for i in request.args:
        allergen_list.append(i)
    return render_template('expiry_date.html')

@app.route('/updateexpdatedata', methods = ["GET"])
def updateexpdatedata():
    expdate = request.args['expiry_date']
    desc = request.args['description']
    addfooddata(type_list, allergen_list, expdate, desc)
    return render_template('thank_you_donors.html')

# collecting
@app.route('/collect', methods = ["GET"])
def collect():
    return render_template('workers_login_page.html')

@app.route('/worker_login', methods = ["GET"])
def collecting():
    return render_template('map.html' )

@app.route('/next', methods = ["GET"])
def location():
    return render_template('checklist.html', checked = False, datalist = None)    

@app.route('/filter', methods = ["GET"])
def filtering():
    for i in request.args:
        check_list.append(i)
    datalist = search(check_list)
    return render_template('checklist.html', checked = True, datalist = datalist)

@app.route('/collecting', methods = ["GET"])
def choosingfood():
    return render_template('collected_food.html')

@app.route('/updatecollectiondata', methods = ["GET"])
def updating():
    no_ = request.args['serial_number']
    update(no_)
    return render_template('thank_you_workers.html')

app.run(host='0.0.0.0', port='80')

